<?php
session_start();
$db=mysqli_connect('localhost','kvs_veg','kvs_veg','kvs') or die("Database is not connected !");
?>