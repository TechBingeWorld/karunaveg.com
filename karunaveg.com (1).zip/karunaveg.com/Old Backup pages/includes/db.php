<?php
session_start();
$db=mysqli_connect('localhost','root','','kvs') or die("Database is not connected !");
?>